<?php echo Form::open(array("class"=>"form-horizontal")); ?>

	<fieldset>
		<div class="form-group">
			<?php echo Form::label('Usuario', 'usuario', array('class'=>'control-label')); ?>

				<?php echo Form::input('usuario', Input::post('usuario', isset($usuario) ? $usuario->usuario : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Usuario')); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('Nombre', 'nombre', array('class'=>'control-label')); ?>

				<?php echo Form::input('nombre', Input::post('nombre', isset($usuario) ? $usuario->nombre : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Nombre')); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('Contrasena', 'contrasena', array('class'=>'control-label')); ?>

				<?php echo Form::input('contrasena', Input::post('contrasena', isset($usuario) ? $usuario->contrasena : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Contrasena')); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('Activo', 'activo', array('class'=>'control-label')); ?>

				<?php echo Form::input('activo', Input::post('activo', isset($usuario) ? $usuario->activo : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Activo')); ?>

		</div>
		<div class="form-group">
			<label class='control-label'>&nbsp;</label>
			<?php echo Form::submit('submit', 'Save', array('class' => 'btn btn-primary')); ?>		</div>
	</fieldset>
<?php echo Form::close(); ?>