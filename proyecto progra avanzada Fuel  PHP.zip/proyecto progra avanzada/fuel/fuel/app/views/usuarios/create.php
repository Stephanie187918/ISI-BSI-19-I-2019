<h2>New Usuario</h2>
<br>

<?php echo render('usuarios/_form'); ?>


<p><?php echo Html::anchor('usuarios', 'Back'); ?></p>
