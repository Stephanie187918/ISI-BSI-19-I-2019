<h2>Editing Usuario</h2>
<br>

<?php echo render('usuarios/_form'); ?>
<p>
	<?php echo Html::anchor('usuarios/view/'.$usuario->id, 'View'); ?> |
	<?php echo Html::anchor('usuarios', 'Back'); ?></p>
