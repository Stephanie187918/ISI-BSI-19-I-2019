<h2>Viewing #<?php echo $usuario->id; ?></h2>

<p>
	<strong>Usuario:</strong>
	<?php echo $usuario->usuario; ?></p>
<p>
	<strong>Nombre:</strong>
	<?php echo $usuario->nombre; ?></p>
<p>
	<strong>Contrasena:</strong>
	<?php echo $usuario->contrasena; ?></p>
<p>
	<strong>Activo:</strong>
	<?php echo $usuario->activo; ?></p>

<?php echo Html::anchor('usuarios/edit/'.$usuario->id, 'Edit'); ?> |
<?php echo Html::anchor('usuarios', 'Back'); ?>