<h2>Listing Usuarios</h2>
<br>
<?php if ($usuarios): ?>
<table class="table table-striped">
	<thead>
		<tr>
			<th>Usuario</th>
			<th>Nombre</th>
			<th>Contrasena</th>
			<th>Activo</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php foreach ($usuarios as $item): ?>		<tr>

			<td><?php echo $item->usuario; ?></td>
			<td><?php echo $item->nombre; ?></td>
			<td><?php echo $item->contrasena; ?></td>
			<td><?php echo $item->activo; ?></td>
			<td>
				<?php echo Html::anchor('usuarios/view/'.$item->id, 'View'); ?> |
				<?php echo Html::anchor('usuarios/edit/'.$item->id, 'Edit'); ?> |
				<?php echo Html::anchor('usuarios/delete/'.$item->id, 'Delete', array('onclick' => "return confirm('Are you sure?')")); ?>

			</td>
		</tr>
<?php endforeach; ?>	</tbody>
</table>

<?php else: ?>
<p>No Usuarios.</p>

<?php endif; ?><p>
	<?php echo Html::anchor('usuarios/create', 'Add new Usuario', array('class' => 'btn btn-success')); ?>

</p>
