<h2>Viewing <span class='muted'>#<?php echo $post->id; ?></span></h2>

<p>
	<strong>Titulo:</strong>
	<?php echo $post->titulo; ?></p>
<p>
	<strong>Resumen:</strong>
	<?php echo $post->resumen; ?></p>
<p>
	<strong>Cuerpo:</strong>
	<?php echo $post->cuerpo; ?></p>

<?php echo Html::anchor('post/edit/'.$post->id, 'Edit'); ?> |
<?php echo Html::anchor('post', 'Back'); ?>