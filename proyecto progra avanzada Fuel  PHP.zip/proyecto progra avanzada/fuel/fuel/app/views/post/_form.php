<?php echo Form::open(array("class"=>"form-horizontal")); ?>

	<fieldset>
		<div class="form-group">
			<?php echo Form::label('Titulo', 'titulo', array('class'=>'control-label')); ?>

				<?php echo Form::input('titulo', Input::post('titulo', isset($post) ? $post->titulo : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Titulo')); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('Resumen', 'resumen', array('class'=>'control-label')); ?>

				<?php echo Form::input('resumen', Input::post('resumen', isset($post) ? $post->resumen : ''), array('class' => 'col-md-4 form-control', 'placeholder'=>'Resumen')); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('Cuerpo', 'cuerpo', array('class'=>'control-label')); ?>

				<?php echo Form::textarea('cuerpo', Input::post('cuerpo', isset($post) ? $post->cuerpo : ''), array('class' => 'col-md-8 form-control', 'rows' => 8, 'placeholder'=>'Cuerpo')); ?>

		</div>
		<div class="form-group">
			<label class='control-label'>&nbsp;</label>
			<?php echo Form::submit('submit', 'Save', array('class' => 'btn btn-primary')); ?>		</div>
	</fieldset>
<?php echo Form::close(); ?>