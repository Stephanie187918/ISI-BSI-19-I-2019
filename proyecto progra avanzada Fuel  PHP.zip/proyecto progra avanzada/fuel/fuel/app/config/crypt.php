<?php
return array (
  'sodium' => 
  array (
    'cipherkey' => '244c2b00dc3c5b14be4f183bbda8125ef4cedafad696fa3953a7fa708dcbb039',
  ),
);
