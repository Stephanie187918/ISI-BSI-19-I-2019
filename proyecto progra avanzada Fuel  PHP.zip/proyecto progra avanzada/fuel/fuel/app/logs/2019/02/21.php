<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-02-21 22:06:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:07:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:13:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:13:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:26:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:26:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:26:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:27:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:28:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:29:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:31:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:31:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:41:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:42:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-21 22:43:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-02-21 22:43:46 --> 1045 - SQLSTATE[HY000] [1045] Access denied for user '**********'@'localhost' (using password: YES) in C:\xampp\htdocs\fuelphp\fuel\core\classes\database\pdo\connection.php on line 86
ERROR - 2019-02-21 22:43:46 --> 1045 - SQLSTATE[HY000] [1045] Access denied for user 'root'@'localhost' (using password: YES) in C:\xampp\htdocs\fuelphp\fuel\core\classes\database\pdo\connection.php on line 470
WARNING - 2019-02-21 22:44:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-02-21 22:44:41 --> 1045 - SQLSTATE[HY000] [1045] Access denied for user '**********'@'localhost' (using password: YES) in C:\xampp\htdocs\fuelphp\fuel\core\classes\database\pdo\connection.php on line 86
WARNING - 2019-02-21 22:49:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-02-21 22:49:21 --> 42S02 - SQLSTATE[42S02]: Base table or view not found: 1146 Table 'intranet.usuarios' doesn't exist with query: "SELECT `usuarios`.* FROM `usuarios`" in C:\xampp\htdocs\fuelphp\fuel\core\classes\database\pdo\connection.php on line 223
