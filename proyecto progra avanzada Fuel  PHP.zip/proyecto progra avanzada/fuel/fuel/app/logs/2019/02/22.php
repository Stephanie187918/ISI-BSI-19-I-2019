<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-02-22 18:01:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-22 18:17:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-22 18:20:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-22 18:20:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-22 18:20:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-02-22 18:20:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
