<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-03-07 22:34:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-03-07 22:34:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-03-07 22:35:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
