<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-04-09 00:33:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-09 00:34:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
