<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-04-23 18:35:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-23 18:35:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
