<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-04-11 15:49:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-11 15:49:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
