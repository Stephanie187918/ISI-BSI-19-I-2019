<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2019-04-08 19:14:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:14:35 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:14:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:14:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:14:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:17:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:18:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:18:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-04-08 19:18:06 --> Error - Class 'Orm\Model' not found in C:\xampp\htdocs\fuel\fuelphp\fuel\app\classes\model\post.php on line 4
WARNING - 2019-04-08 19:18:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:19:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:19:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-04-08 19:19:12 --> Error - Class 'Orm\Model' not found in C:\xampp\htdocs\fuel\fuelphp\fuel\app\classes\model\post.php on line 4
WARNING - 2019-04-08 19:19:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-04-08 19:19:34 --> Error - Class 'Orm\Model' not found in C:\xampp\htdocs\fuel\fuelphp\fuel\app\classes\model\post.php on line 4
WARNING - 2019-04-08 19:19:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:20:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:20:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2019-04-08 19:20:31 --> Error - Class 'Orm\Model' not found in C:\xampp\htdocs\fuel\fuelphp\fuel\app\classes\model\post.php on line 4
WARNING - 2019-04-08 19:26:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:26:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:26:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:26:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:26:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:28:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:28:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:28:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:29:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:32:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:36:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:36:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:37:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:37:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:37:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:41:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:46:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:47:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:50:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:50:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:53:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2019-04-08 19:53:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
