<?php
class Controller_Usuarios extends Controller_Template
{

	public function action_index()
	{
		$data['usuarios'] = Model_Usuario::find_all();
		$this->template->title = "Usuarios";
		$this->template->content = View::forge('usuarios/index', $data);

	}

	public function action_view($id = null)
	{
		is_null($id) and Response::redirect('usuarios');

		$data['usuario'] = Model_Usuario::find_by_pk($id);

		$this->template->title = "Usuario";
		$this->template->content = View::forge('usuarios/view', $data);

	}

	public function action_create()
	{
		if (Input::method() == 'POST')
		{
			$val = Model_Usuario::validate('create');

			if ($val->run())
			{
				$usuario = Model_Usuario::forge(array(
					'usuario' => Input::post('usuario'),
					'nombre' => Input::post('nombre'),
					'contrasena' => Input::post('contrasena'),
					'activo' => Input::post('activo'),
				));

				if ($usuario and $usuario->save())
				{
					Session::set_flash('success', 'Added usuario #'.$usuario->id.'.');
					Response::redirect('usuarios');
				}
				else
				{
					Session::set_flash('error', 'Could not save usuario.');
				}
			}
			else
			{
				Session::set_flash('error', $val->error());
			}
		}

		$this->template->title = "Usuarios";
		$this->template->content = View::forge('usuarios/create');

	}

	public function action_edit($id = null)
	{
		is_null($id) and Response::redirect('usuarios');

		$usuario = Model_Usuario::find_one_by_id($id);

		if (Input::method() == 'POST')
		{
			$val = Model_Usuario::validate('edit');

			if ($val->run())
			{
				$usuario->usuario = Input::post('usuario');
				$usuario->nombre = Input::post('nombre');
				$usuario->contrasena = Input::post('contrasena');
				$usuario->activo = Input::post('activo');

				if ($usuario->save())
				{
					Session::set_flash('success', 'Updated usuario #'.$id);
					Response::redirect('usuarios');
				}
				else
				{
					Session::set_flash('error', 'Nothing updated.');
				}
			}
			else
			{
				Session::set_flash('error', $val->error());
			}
		}

		$this->template->set_global('usuario', $usuario, false);
		$this->template->title = "Usuarios";
		$this->template->content = View::forge('usuarios/edit');

	}

	public function action_delete($id = null)
	{
		if ($usuario = Model_Usuario::find_one_by_id($id))
		{
			$usuario->delete();

			Session::set_flash('success', 'Deleted usuario #'.$id);
		}

		else
		{
			Session::set_flash('error', 'Could not delete usuario #'.$id);
		}

		Response::redirect('usuarios');

	}

}
