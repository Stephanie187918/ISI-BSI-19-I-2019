<?php  
   class Controller_Book extends Controller_Template {
      public $template = 'layout'; 
      public function action_index() { 
         
         // Create the view object 
         $view = View::forge('book/index');  
         
         // set the template variables 
         $this->template->title = "Book index page"; 
         $this->template->content = $view; 
      } 
   } 
?>