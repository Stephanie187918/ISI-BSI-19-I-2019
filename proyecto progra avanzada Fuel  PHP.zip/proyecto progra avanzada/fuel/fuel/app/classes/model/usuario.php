<?php
class Model_Usuario extends Model_Crud
{
	protected static $_table_name = 'usuarios';
	
	public static function validate($factory)
	{
		$val = Validation::forge($factory);
		$val->add_field('usuario', 'Usuario', 'required|max_length[255]');
		$val->add_field('nombre', 'Nombre', 'required|max_length[255]');
		$val->add_field('contrasena', 'Contrasena', 'required|max_length[255]');
		$val->add_field('activo', 'Activo', 'required');

		return $val;
	}

}
